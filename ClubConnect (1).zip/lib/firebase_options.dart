import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

// Above is the Import
class DefaultFirebaseOptions {
  /// Returns Firebase configuration depending on the current platform; But this is for testing on Flutlab.io when using the downloaded file then it will only work on APPLE IPHONE
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;

    switch (defaultTargetPlatform) {
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError(
            'This platform is not supported. Please contact the developer.');
    }
  }

// Firebase keys for the application
  // ---------------- WEB ----------------
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyA5lodRp7lhdeZE1XlifpyYhD1hKajwlYE',
    authDomain: 'clubconnect-6fb18.firebaseapp.com',
    projectId: 'clubconnect-6fb18',
    storageBucket: 'clubconnect-6fb18.appspot.com',
    messagingSenderId: '718024650520',
    appId: '1:718024650520:web:REPLACE_WITH_WEB_ID',
  );

  // ---------------- iOS ----------------
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyA5lodRp7lhdeZE1XlifpyYhD1hKajwlYE',
    iosBundleId: 'com.example.clubconnect',
    appId: '1:718024650520:ios:2e16bd2f20281b964c786d',
    messagingSenderId: '718024650520',
    projectId: 'clubconnect-6fb18',
    storageBucket: 'clubconnect-6fb18.appspot.com',
  );

  // ---------------- ANDROID ----------------
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyA5lodRp7lhdeZE1XlifpyYhD1hKajwlYE',
    appId: '1:718024650520:android:REPLACE_WITH_ANDROID_ID',
    messagingSenderId: '718024650520',
    projectId: 'clubconnect-6fb18',
    storageBucket: 'clubconnect-6fb18.appspot.com',
  );
}
