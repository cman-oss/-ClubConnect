import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/firebase_service.dart';

class ClubDetailScreen extends StatefulWidget {
  final String clubId;
  const ClubDetailScreen({super.key, required this.clubId});

  @override
  State<ClubDetailScreen> createState() => _ClubDetailScreenState();
}

class _ClubDetailScreenState extends State<ClubDetailScreen> {
  final FirebaseService _svc = FirebaseService();
  final TextEditingController _msg = TextEditingController();

  Map<String, dynamic>? _club;
  bool _loading = true;

  void _load() async {
    final snap = await _svc.getClub(widget.clubId);
    setState(() {
      _club = snap.data(); // fixed type
      _loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final uid = FirebaseAuth.instance.currentUser!.uid;
    final members = List<String>.from(_club?["members"] ?? []);
    final isMember = members.contains(uid);

    return Scaffold(
      appBar: AppBar(title: Text(_club?["name"] ?? "Club")),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: () async {
              if (isMember) {
                await _svc.leaveClub(widget.clubId, uid); // fixed
              } else {
                await _svc.joinClub(widget.clubId, uid); // fixed
              }
              _load();
            },
            child: Text(isMember ? "Leave Club" : "Join Club"),
          ),
          Expanded(
            child: StreamBuilder(
              stream: _svc.messagesStream(widget.clubId),
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return const Center(child: CircularProgressIndicator());
                final docs = snapshot.data!.docs;
                return ListView(
                  children: docs
                      .map((d) => ListTile(
                            title: Text(d["senderName"]),
                            subtitle: Text(d["text"]),
                          ))
                      .toList(),
                );
              },
            ),
          ),
          Row(
            children: [
              Expanded(child: TextField(controller: _msg)),
              IconButton(
                icon: const Icon(Icons.send),
                onPressed: () {
                  _svc.sendMessage(widget.clubId, _msg.text);
                  _msg.clear();
                },
              )
            ],
          )
        ],
      ),
    );
  }
}
