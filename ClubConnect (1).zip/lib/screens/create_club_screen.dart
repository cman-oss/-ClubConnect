import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

// Above is the Imports
class CreateClubScreen extends StatefulWidget {
  @override
  _CreateClubScreenState createState() => _CreateClubScreenState();
}

class _CreateClubScreenState extends State<CreateClubScreen> {
  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final FirebaseService _service = FirebaseService();
  bool _loading = false;

  void _createClub() async {
    if (_nameCtrl.text.trim().isEmpty) return;

    setState(() => _loading = true);
    await _service.createClub(_nameCtrl.text.trim(), _descCtrl.text.trim());
    setState(() => _loading = false);

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Create Club")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          TextField(
            controller: _nameCtrl,
            decoration: InputDecoration(labelText: "Club Name"),
          ),
          TextField(
            controller: _descCtrl,
            decoration: InputDecoration(labelText: "Description"),
          ),
          SizedBox(height: 20),
          ElevatedButton(
              onPressed: _loading ? null : _createClub, child: Text("Create")),
        ]),
      ),
    );
  }
}
