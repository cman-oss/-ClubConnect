import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

// Above is the Imports
class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final FirebaseService _service = FirebaseService();
  bool _loading = false;

  void _login() async {
    setState(() {
      _loading = true;
    });
    try {
      await _service.signIn(_emailCtrl.text.trim(), _passCtrl.text.trim());
      Navigator.pushReplacementNamed(context, '/clubs');
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Login failed: $e')));
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffd28922),
      appBar: AppBar(
        title: Text(
          'ClubConnect — Login',
          style: const TextStyle(
            fontFamily: 'Lexend',
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          TextField(
            controller: _emailCtrl,
            decoration: InputDecoration(labelText: 'Email'),
          ),
          TextField(
            controller: _passCtrl,
            decoration: InputDecoration(labelText: 'Password'),
            obscureText: true,
          ),
          SizedBox(height: 16),
          ElevatedButton(
              onPressed: _loading ? null : _login, child: Text('Login')),
          TextButton(
              onPressed: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => RegisterScreen())),
              child: Text('Register')),
          TextButton(
              onPressed: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => RecoveryScreen())),
              child: Text('Forgot password')),
          Text("Comments By Application Users",
              style: TextStyle(
                color: Colors.blue,
                fontFamily: 'Lexend',
                fontSize: 17,
              )),
          Text(
              "I Never missed a club meeting again with this invention - Nagababu"),
          Text("I had never seen a easier application than this - Kishor"),
          Text(
              "I have seem many applications like this but, this works prefectly for Kids who easily get distracted - Manaish"),
          TextField(
            decoration: InputDecoration(
                labelText:
                    'Give a rating from 1-10 for the application for improvement in the future'),
          ),
          Image.asset(
            'assets/Logo.png',
            width: 200,
            height: 200,
          ),
        ]),
      ),
    );
  }
}

// Register screen
class RegisterScreen extends StatefulWidget {
  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final FirebaseService _service = FirebaseService();
  bool _loading = false;

  void _register() async {
    setState(() => _loading = true);
    try {
      await _service.register(_emailCtrl.text.trim(), _passCtrl.text.trim());
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Register failed: $e')));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text('Register'), backgroundColor: Colors.amberAccent),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
                controller: _emailCtrl,
                decoration: InputDecoration(labelText: 'Email')),
            TextField(
                controller: _passCtrl,
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true),
            SizedBox(height: 16),
            ElevatedButton(
                onPressed: _loading ? null : _register,
                child: Text('Create Account')),
          ],
        ),
      ),
    );
  }
}

// Recovery screen
class RecoveryScreen extends StatefulWidget {
  @override
  _RecoveryScreenState createState() => _RecoveryScreenState();
}

class _RecoveryScreenState extends State<RecoveryScreen> {
  final _emailCtrl = TextEditingController();
  final FirebaseService _service = FirebaseService();
  bool _loading = false;

  void _recover() async {
    setState(() => _loading = true);
    try {
      await _service.sendPasswordReset(_emailCtrl.text.trim());
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
              'Password reset email sent to your email, please also check the spam folder')));
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e, please try again.')));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Account Recovery')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          TextField(
              controller: _emailCtrl,
              decoration: InputDecoration(labelText: 'Email')),
          SizedBox(height: 16),
          ElevatedButton(
              onPressed: _loading ? null : _recover,
              child: Text('Send Reset Email')),
        ]),
      ),
    );
  }
}
