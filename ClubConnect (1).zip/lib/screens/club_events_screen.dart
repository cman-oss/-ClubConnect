import 'package:flutter/material.dart';
import '../services/firebase_service.dart';

class ClubEventsScreen extends StatefulWidget {
  final String clubId;
  const ClubEventsScreen({super.key, required this.clubId});

  @override
  State<ClubEventsScreen> createState() => _ClubEventsScreenState();
}

class _ClubEventsScreenState extends State<ClubEventsScreen> {
  final FirebaseService _svc = FirebaseService();
  bool _loadingEvents = true;
  bool _loadingAnnouncements = true;

  List<Map<String, dynamic>> _events = [];
  List<Map<String, dynamic>> _announcements = [];

  @override
  void initState() {
    super.initState();
    _loadEvents();
    _loadAnnouncements();
  }

  Future<void> _loadEvents() async {
    final events = await _svc.getEvents(widget.clubId);
    if (!mounted) return;
    setState(() {
      _events = events;
      _loadingEvents = false;
    });
  }

  Future<void> _loadAnnouncements() async {
    final announcements = await _svc.getAnnouncements(widget.clubId);
    if (!mounted) return;
    setState(() {
      _announcements = announcements;
      _loadingAnnouncements = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Club Events & Announcements")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Upcoming Events",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            _loadingEvents
                ? const CircularProgressIndicator()
                : _events.isEmpty
                    ? const Text("No events yet")
                    : Column(
                        children: _events.map((e) {
                          return Card(
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            child: ListTile(
                              leading: const Icon(Icons.event),
                              title: Text(e["title"]),
                              subtitle: Text(e["dateTime"]),
                            ),
                          );
                        }).toList(),
                      ),
            const SizedBox(height: 16),
            const Text("Announcements",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            _loadingAnnouncements
                ? const CircularProgressIndicator()
                : _announcements.isEmpty
                    ? const Text("No announcements yet")
                    : Column(
                        children: _announcements.map((a) {
                          return Card(
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            child: ListTile(
                              leading: const Icon(Icons.announcement),
                              title: Text(a["title"]),
                              subtitle: Text(a["content"]),
                            ),
                          );
                        }).toList(),
                      ),
          ],
        ),
      ),
    );
  }
}
