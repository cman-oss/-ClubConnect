import 'package:flutter/material.dart';
import '../services/firebase_service.dart';
import 'club_detail_screen.dart';
import 'create_club_screen.dart';

// Above is the Imports
class ClubListScreen extends StatelessWidget {
  final FirebaseService _service = FirebaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Clubs",
          style: TextStyle(
            fontFamily: 'Lexend',
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.redAccent,
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => CreateClubScreen()));
            },
          ),
        ],
      ),
      body: StreamBuilder(
        stream: _service.clubsStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData)
            return Center(child: CircularProgressIndicator());

          final docs = snapshot.data!.docs;
          if (docs.isEmpty) return Center(child: Text("No clubs yet"));

          return ListView(
            children: docs
                .map((doc) => ListTile(
                      title: Text(
                        doc["name"],
                        style: TextStyle(color: Colors.red),
                      ),
                      subtitle: Text(doc["description"] ?? ""),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ClubDetailScreen(clubId: doc.id),
                          ),
                        );
                      },
                    ))
                .toList(),
          );
        },
      ),
    );
  }
}
