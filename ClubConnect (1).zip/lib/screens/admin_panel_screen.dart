import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/firebase_service.dart';
import '../services/attendance_api.dart';

class AdminPanelScreen extends StatefulWidget {
  final String clubId;
  const AdminPanelScreen({super.key, required this.clubId});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  final FirebaseService _svc = FirebaseService();
  final AttendanceApi _attendance = AttendanceApi();

  final TextEditingController _announcementCtrl = TextEditingController();
  bool _loadingMembers = true;
  List<Map<String, dynamic>> _members = [];

  @override
  void initState() {
    super.initState();
    _loadMembers();
  }

  Future<void> _loadMembers() async {
    final members = await _svc.getMembers(widget.clubId);
    if (!mounted) return;

    setState(() {
      _members = members;
      _loadingMembers = false;
    });
  }

  Future<void> _removeMember(String userId) async {
    await _svc.removeMember(widget.clubId, userId);
    _loadMembers();
  }

  Future<void> _promoteAdmin(String userId) async {
    await _svc.promoteAdmin(widget.clubId, userId);
    _loadMembers();
  }

  Future<void> _postAnnouncement() async {
    if (_announcementCtrl.text.trim().isEmpty) return;
    await _svc.postAnnouncement(
        widget.clubId, "Announcement", _announcementCtrl.text.trim());
    _announcementCtrl.clear();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Announcement posted")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Panel")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // ----------- Post Announcement ----------
            TextField(
              controller: _announcementCtrl,
              decoration: const InputDecoration(
                labelText: "Write announcement",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _postAnnouncement,
              child: const Text("Post Announcement"),
            ),
            const SizedBox(height: 16),

            // ----------- Members List ----------
            _loadingMembers
                ? const CircularProgressIndicator()
                : Expanded(
                    child: ListView.builder(
                      itemCount: _members.length,
                      itemBuilder: (context, index) {
                        final member = _members[index];
                        final userId = member["uid"];
                        final email = member["email"];
                        final isAdmin = member["isAdmin"] ?? false;

                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          child: ListTile(
                            title: Text(email),
                            subtitle: Text(isAdmin ? "Admin" : "Member"),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (!isAdmin)
                                  IconButton(
                                    icon: const Icon(Icons.upgrade),
                                    tooltip: "Promote to Admin",
                                    onPressed: () => _promoteAdmin(userId),
                                  ),
                                IconButton(
                                  icon: const Icon(Icons.remove_circle),
                                  tooltip: "Remove Member",
                                  onPressed: () => _removeMember(userId),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
