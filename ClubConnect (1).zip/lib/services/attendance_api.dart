import 'package:cloud_firestore/cloud_firestore.dart';

class AttendanceApi {
  final _db = FirebaseFirestore.instance;

  // Stream attendance for a club
  Stream<Map<String, bool>> attendanceStream(String clubId) {
    return _db
        .collection("clubs")
        .doc(clubId)
        .collection("attendance")
        .snapshots()
        .map((snap) {
      final Map<String, bool> map = {};
      for (var doc in snap.docs) {
        map[doc.id] = doc["attended"] ?? false;
      }
      return map;
    });
  }

  // Mark attendance for a user
  Future<void> markAttendance(String clubId, String userId) async {
    await _db
        .collection("clubs")
        .doc(clubId)
        .collection("attendance")
        .doc(userId)
        .set({
      "attended": true,
      "timestamp": FieldValue.serverTimestamp(),
    });
  }

  // Remove attendance (optional)
  Future<void> removeAttendance(String clubId, String userId) async {
    await _db
        .collection("clubs")
        .doc(clubId)
        .collection("attendance")
        .doc(userId)
        .delete();
  }
}
