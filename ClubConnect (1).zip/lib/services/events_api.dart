import 'package:cloud_firestore/cloud_firestore.dart';

class EventsApi {
  final _db = FirebaseFirestore.instance;

  Stream<List<Map<String, dynamic>>> streamEvents(String clubId) {
    return _db
        .collection("clubs")
        .doc(clubId)
        .collection("events")
        .orderBy("dateTime")
        .snapshots()
        .map((snap) => snap.docs.map((d) => d.data()).toList());
  }
}
// This is the api for firestore
