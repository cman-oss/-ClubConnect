import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class HolidayApi {
  Future<List<dynamic>> getHolidays() async {
    final url =
        Uri.parse("https://date.nager.at/api/v3/PublicHolidays/2026/US");

    final res = await http.get(url);
    if (res.statusCode != 200) return [];

    final data = json.decode(res.body);
    return data;
  }
}
// API setup for calendar for 2026
