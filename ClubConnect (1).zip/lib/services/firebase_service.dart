import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirebaseService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ---------- Authentication ----------
  Future<void> signIn(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
    } catch (e) {
      throw Exception(_parseFirebaseError(e));
    }
  }

  Future<void> register(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
    } catch (e) {
      throw Exception(_parseFirebaseError(e));
    }
  }

  Future<void> sendPasswordReset(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw Exception(_parseFirebaseError(e));
    }
  }

  String? getCurrentUid() => _auth.currentUser?.uid;

  // ---------- Clubs ----------
  Stream<QuerySnapshot<Map<String, dynamic>>> clubsStream() {
    return _firestore.collection('clubs').orderBy('name').snapshots();
  }

  Future<void> createClub(String name, String description) async {
    await _firestore.collection('clubs').add({
      'name': name,
      'description': description,
      'members': [],
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<DocumentSnapshot<Map<String, dynamic>>> getClub(String clubId) async {
    return await _firestore.collection('clubs').doc(clubId).get();
  }

  Future<void> joinClub(String clubId, String uid) async {
    await _firestore.collection('clubs').doc(clubId).update({
      'members': FieldValue.arrayUnion([uid]),
    });
  }

  Future<void> leaveClub(String clubId, String uid) async {
    await _firestore.collection('clubs').doc(clubId).update({
      'members': FieldValue.arrayRemove([uid]),
    });
  }

  // ---------- Messages ----------
  Stream<QuerySnapshot<Map<String, dynamic>>> messagesStream(String clubId) {
    return _firestore
        .collection('clubs')
        .doc(clubId)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  Future<void> sendMessage(String clubId, String message) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) throw Exception('User not logged in');

    await _firestore
        .collection('clubs')
        .doc(clubId)
        .collection('messages')
        .add({
      'uid': uid,
      'message': message,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  // ---------- Helper ----------
  String _parseFirebaseError(Object e) {
    if (e is FirebaseAuthException) return e.message ?? 'Authentication error';
    if (e is FirebaseException) return e.message ?? 'Firebase error';
    return e.toString();
  }
}
