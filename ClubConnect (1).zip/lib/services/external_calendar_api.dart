import 'dart:convert';
import 'package:http/http.dart' as http;

class ExternalCalendarApi {
  Future<List<Map<String, dynamic>>> getHolidays() async {
    final url =
        Uri.parse("https://date.nager.at/api/v3/PublicHolidays/2025/US");

    final response = await http.get(url);

    if (response.statusCode != 200) {
      return [];
    }

    final List data = json.decode(response.body);

    return data.cast<Map<String, dynamic>>();
  }
}
// This is the calendar from 2025
